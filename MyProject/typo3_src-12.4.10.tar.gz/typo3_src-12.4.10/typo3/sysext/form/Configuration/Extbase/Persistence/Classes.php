<?php

declare(strict_types=1);

return [
    \TYPO3\CMS\Form\Mvc\Property\TypeConverter\PseudoFileReference::class => [
        'tableName' => 'sys_file_reference',
    ],
];
