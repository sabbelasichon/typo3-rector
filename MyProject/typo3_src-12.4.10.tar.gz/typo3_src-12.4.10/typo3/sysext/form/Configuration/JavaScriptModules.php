<?php

return [
    'dependencies' => [
        'backend',
        'core',
    ],
    'imports' => [
        '@typo3/form/backend/' => 'EXT:form/Resources/Public/JavaScript/backend/',
    ],
];
