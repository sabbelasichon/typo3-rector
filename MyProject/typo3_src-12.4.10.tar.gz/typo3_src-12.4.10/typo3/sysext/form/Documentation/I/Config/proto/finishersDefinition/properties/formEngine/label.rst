.. include:: /Includes.rst.txt

Finisher options are overwritable within the ``form plugin``.
If the "Override finisher settings" checkbox is selected within the ``form plugin``, every finisher who has a - :ref:`"FormEngine"<prototypes.\<prototypeIdentifier>.finishersdefinition.\<finisheridentifier>.formengine>` configuration, is shown in a separate tab.
``label`` is the label for such a tab.
