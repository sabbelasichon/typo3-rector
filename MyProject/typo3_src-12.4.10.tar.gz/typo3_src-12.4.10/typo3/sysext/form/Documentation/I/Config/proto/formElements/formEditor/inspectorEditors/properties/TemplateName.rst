.. include:: /Includes.rst.txt

The inline HTML template which is used for this inspector editor.
Must be equal to an existing array key within ``prototypes.<prototypeIdentifier>.formEditor.formEditorPartials`` and must be started with 'Inspector-' by convention.
