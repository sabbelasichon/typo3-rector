.. include:: /Includes.rst.txt

This label will be shown within the - :ref:`"Inspector [CollectionElementHeaderEditor]"<prototypes.\<prototypeidentifier>.formelementsdefinition.\<formelementtypeidentifier>.formeditor.editors.*.collectionelementheadereditor>` if the finisher is selected.
