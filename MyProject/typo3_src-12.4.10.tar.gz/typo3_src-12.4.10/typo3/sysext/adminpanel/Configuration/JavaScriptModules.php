<?php

return [
    'dependencies' => [],
    'imports' => [
        '@typo3/adminpanel/' => 'EXT:adminpanel/Resources/Public/JavaScript/',
    ],
];
