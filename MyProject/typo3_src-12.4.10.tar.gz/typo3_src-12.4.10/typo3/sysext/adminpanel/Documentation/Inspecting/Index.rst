.. include:: /Includes.rst.txt

.. _inspecting:

=================
Inspecting a page
=================

For every page, the Admin Panel displays information about TypoScript, load
time and requests, and errors and warnings.

.. toctree::
   :maxdepth: 3
   :titlesonly:

   TypoScript/Index
   Info/Index
   Debug/Index
