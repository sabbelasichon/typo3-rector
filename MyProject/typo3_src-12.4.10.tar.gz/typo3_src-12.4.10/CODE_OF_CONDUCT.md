# Code of Conduct

This project uses the
[TYPO3 Code of Conduct](https://typo3.org/community/values/code-of-conduct).

When you contribute to this project or interact with community members,
you agree to adhere to this code of conduct.
